"""Dados embutidos no pacote (contornos territoriais em GeoJSON)."""
