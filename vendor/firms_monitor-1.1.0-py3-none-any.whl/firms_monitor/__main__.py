import sys

from firms_monitor.cli import main

sys.exit(main())
